#include "ultra_sonic.h"
#include "main.h"
#include "i2c_lcd.h"
#include "servo_motor.h"
#include <stdio.h>

extern TIM_HandleTypeDef htim3;
extern volatile float distance;  // 전역 변수 직접 선언

void ultra_sonic_init(void)
{
    HAL_TIM_IC_Start_IT(&htim3, TIM_CHANNEL_2);
}

void ultra_sonic_trigger(void)
{
    HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_SET);
    delay_us(10);
    HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_RESET);
}

float ultra_sonic_get_distance(void)
{
    ultra_sonic_trigger();
    HAL_Delay(50);
    return distance;
}

void ultra_sonic_process(void)
{
    static int door_state = 0;
    static uint32_t detect_timer = 0, lost_timer = 0;

    // TRIG 신호 주기적으로 발생
    ultra_sonic_trigger();
    osDelay(50);  // 짧은 대기 (ECHO 측정용)

    // distance는 인터럽트(HAL_TIM_IC_CaptureCallback)에서 자동 갱신
    float d = distance;

    printf("Measured Distance: %.2f cm\r\n", d);  // 디버깅용

    if (d > 0 && d <= 7.0f)
    {
        detect_timer += 100;
        lost_timer = 0;
        if (detect_timer >= 2000 && door_state == 0)
        {
            set_servo_angle(90);
            door_state = 1;
            printf("Door Opened\r\n");
        }
    }
    else
    {
        lost_timer += 100;
        detect_timer = 0;
        if (lost_timer >= 2000 && door_state == 1)
        {
            set_servo_angle(0);
            door_state = 0;
            printf("Door Closed\r\n");
        }
    }

    char buf[32];
    move_cursor(1, 0);
    snprintf(buf, sizeof(buf), "D:%.1fcm %s  ", d, door_state ? "OPEN" : "CLOSE");
    lcd_string((uint8_t*)buf);
}
