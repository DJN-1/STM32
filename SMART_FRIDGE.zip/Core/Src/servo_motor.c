#include "servo_motor.h"
#include "main.h"

extern TIM_HandleTypeDef htim5;

void servo_motor_init(void)
{
    HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_2);
}

void set_servo_angle(int angle)
{
    // 0도: 40, 90도: 85, 180도: 130 (필요에 따라 보정)
    int compare_value;
    if(angle <= 0) compare_value = 40;
    else if(angle >= 180) compare_value = 130;
    else compare_value = 40 + (angle * (130 - 40)) / 180;

    __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_2, compare_value);
}
