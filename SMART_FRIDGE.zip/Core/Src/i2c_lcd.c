#include "main.h"
#include "stm32f4xx_hal.h"
#include <string.h>
#include <stdio.h>
#include "i2c_lcd.h"

extern I2C_HandleTypeDef hi2c1;

#define I2C_LCD_ADDRESS (0x27 << 1)
#define BACKLIGHT 0x08

void lcd_command(uint8_t command)
{
    uint8_t high_nibble = command & 0xF0;
    uint8_t low_nibble = (command << 4) & 0xF0;
    uint8_t data[4];
    data[0] = high_nibble | 0x04 | BACKLIGHT;
    data[1] = high_nibble | 0x00 | BACKLIGHT;
    data[2] = low_nibble  | 0x04 | BACKLIGHT;
    data[3] = low_nibble  | 0x00 | BACKLIGHT;
    while (HAL_I2C_Master_Transmit(&hi2c1, I2C_LCD_ADDRESS, data, 4, 100) != HAL_OK) {}
}

void lcd_data(uint8_t data_byte)
{
    uint8_t high_nibble = data_byte & 0xF0;
    uint8_t low_nibble = (data_byte << 4) & 0xF0;
    uint8_t data[4];
    data[0] = high_nibble | 0x05 | BACKLIGHT;
    data[1] = high_nibble | 0x01 | BACKLIGHT;
    data[2] = low_nibble  | 0x05 | BACKLIGHT;
    data[3] = low_nibble  | 0x01 | BACKLIGHT;
    while (HAL_I2C_Master_Transmit(&hi2c1, I2C_LCD_ADDRESS, data, 4, 100) != HAL_OK) {}
}

void i2c_lcd_init(void)
{
    HAL_Delay(50);
    lcd_command(0x33);
    lcd_command(0x32);
    lcd_command(0x28);
    lcd_command(0x0C);
    lcd_command(0x06);
    lcd_command(0x01);
    HAL_Delay(2);
}

void lcd_string(uint8_t *str)
{
    while (*str) lcd_data(*str++);
}

void move_cursor(uint8_t row, uint8_t column)
{
    lcd_command(0x80 | (row << 6) | column);
}
