#ifndef I2C_LCD_H_
#define I2C_LCD_H_

#include <stdint.h>

void i2c_lcd_init(void);
void lcd_command(uint8_t command);
void lcd_data(uint8_t data);
void lcd_string(uint8_t *str);
void move_cursor(uint8_t row, uint8_t column);

#endif /* I2C_LCD_H_ */
