#ifndef INC_SERVO_MOTOR_H_
#define INC_SERVO_MOTOR_H_

#include <stdint.h>

void servo_motor_init(void);
void set_servo_angle(int angle);

#endif /* INC_SERVO_MOTOR_H_ */
