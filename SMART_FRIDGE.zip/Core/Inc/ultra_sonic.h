#ifndef ULTRA_SONIC_H_
#define ULTRA_SONIC_H_

#include <stdint.h>

void ultra_sonic_init(void);
void ultra_sonic_trigger(void);
float ultra_sonic_get_distance(void);
void ultra_sonic_process(void);  // 추가

#endif /* ULTRA_SONIC_H_ */
